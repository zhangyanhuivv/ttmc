#pragma once

/// VERSION 1.3.2
namespace eosio {
   enum version {
      MAJOR 1,
      MINOR 3,
      PATCH 2
   };
}
