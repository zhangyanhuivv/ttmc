/** @file 
 *    @copyright defined in eos/LICENSE.txt 
 *
 * \warning This file is machine generated. DO NOT EDIT.  See core_symbol.hpp.in for changes.
 */

#define CORE_SYMBOL SY(4,TTMC)
#define CORE_SYMBOL_NAME "TTMC"
